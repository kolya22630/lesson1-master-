#include "flywithwings.h"

FlyWithWings::FlyWithWings()
{

}

void FlyWithWings::fly() {
    std::cout << "I'm flying!!" << std::endl;
}
