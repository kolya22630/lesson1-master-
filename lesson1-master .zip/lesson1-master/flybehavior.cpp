#include "flybehavior.h"

FlyBehavior::FlyBehavior()
{

}
