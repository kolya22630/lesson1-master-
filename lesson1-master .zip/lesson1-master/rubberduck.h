#ifndef RUBBERDUCK_H
#define RUBBERDUCK_H

#include "duck.h"

class RubberDuck : public Duck
{
public:
    RubberDuck();
    void display();
};

#endif // RUBBERDUCK_H
