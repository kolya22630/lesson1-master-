#ifndef FLYNOWAY_H
#define FLYNOWAY_H

#include "flybehavior.h"

class FlyNoWay : public FlyBehavior
{
public:
    FlyNoWay();
    void fly();
};

#endif // FLYNOWAY_H
