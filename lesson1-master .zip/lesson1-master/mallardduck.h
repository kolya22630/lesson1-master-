#ifndef MALLARDDUCK_H
#define MALLARDDUCK_H

#include "duck.h"

class MallardDuck : public Duck
{
public:
    MallardDuck();
    void display();
};

#endif // MALLARDDUCK_H
