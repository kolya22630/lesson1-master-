#ifndef FLYWITHWINGS_H
#define FLYWITHWINGS_H

#include "flybehavior.h"

class FlyWithWings : public FlyBehavior
{
public:
    FlyWithWings();
    void fly();
};

#endif // FLYWITHWINGS_H
