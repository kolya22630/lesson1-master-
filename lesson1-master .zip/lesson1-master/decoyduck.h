#ifndef DECOYDUCK_H
#define DECOYDUCK_H

#include "duck.h"

class DecoyDuck : public Duck
{
public:
    DecoyDuck();
    void display();
};

#endif // DECOYDUCK_H
