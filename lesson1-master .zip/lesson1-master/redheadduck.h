#ifndef REDHEADDUCK_H
#define REDHEADDUCK_H

#include "duck.h"

class RedheadDuck : public Duck
{
public:
    RedheadDuck();
    void display();
};

#endif // REDHEADDUCK_H
