#include "flynoway.h"

FlyNoWay::FlyNoWay()
{

}

void FlyNoWay::fly() {
    std::cout << "I can't fly" << std::endl;
}
